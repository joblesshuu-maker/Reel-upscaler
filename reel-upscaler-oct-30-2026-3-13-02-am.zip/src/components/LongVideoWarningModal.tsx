import React from 'react';
import { AlertTriangle, Clock, ArrowRight, X } from 'lucide-react';

interface LongVideoWarningModalProps {
  isOpen: boolean;
  durationSeconds: number;
  onContinue: () => void;
  onCancel: () => void;
}

export const LongVideoWarningModal: React.FC<LongVideoWarningModalProps> = ({
  isOpen,
  durationSeconds,
  onContinue,
  onCancel,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl text-slate-100 space-y-4">
        {/* Warning Icon */}
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-2xl">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-base text-white">
              Lambi Video Warning
            </h3>
            <span className="text-xs text-amber-300 font-medium flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              Duration: {durationSeconds.toFixed(1)}s (&gt; 90s)
            </span>
          </div>
        </div>

        {/* Message */}
        <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-300 leading-relaxed">
          <p className="font-semibold text-amber-200 mb-1">
            "Ye video lambi hai, phone par 10+ minute lag sakte hain."
          </p>
          <p className="text-slate-400">
            Browser memory aur processor par bojh padega. Agar aap chahein toh abhi cancel kar sakte hain ya continue kar sakte hain.
          </p>
        </div>

        {/* Actions: Continue and Cancel buttons */}
        <div className="space-y-2 pt-1">
          <button
            onClick={onContinue}
            className="w-full py-3.5 px-4 rounded-2xl font-bold text-sm bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white shadow-lg shadow-pink-600/25 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Continue (Aage Badhein)</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onCancel}
            className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold text-slate-400 hover:text-white bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 transition-colors"
          >
            Cancel Karein
          </button>
        </div>
      </div>
    </div>
  );
};
