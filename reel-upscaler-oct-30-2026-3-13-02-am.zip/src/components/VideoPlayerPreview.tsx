import React, { useRef, useState } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize2 } from 'lucide-react';

interface VideoPlayerPreviewProps {
  src: string;
  badgeLabel?: string;
  badgeColor?: 'pink' | 'emerald' | 'blue';
  aspectRatioHint?: string;
  autoPlay?: boolean;
}

export const VideoPlayerPreview: React.FC<VideoPlayerPreviewProps> = ({
  src,
  badgeLabel,
  badgeColor = 'pink',
  aspectRatioHint,
  autoPlay = false,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleFullscreen = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!videoRef.current) return;
    if (videoRef.current.requestFullscreen) {
      videoRef.current.requestFullscreen();
    }
  };

  const badgeStyles = {
    pink: 'bg-pink-500/20 text-pink-300 border-pink-500/30',
    emerald: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    blue: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
  };

  return (
    <div 
      onClick={togglePlay}
      className="relative group w-full max-w-[280px] mx-auto rounded-2xl overflow-hidden bg-black/60 border border-slate-800 shadow-xl cursor-pointer aspect-[9/16] max-h-[380px] flex items-center justify-center"
    >
      <video
        ref={videoRef}
        src={src}
        playsInline
        loop
        muted={isMuted}
        autoPlay={autoPlay}
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        className="w-full h-full object-contain"
      />

      {/* Top Badges */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between pointer-events-none z-10">
        {badgeLabel && (
          <span className={`text-[11px] font-semibold px-2.5 py-1 rounded-full border backdrop-blur-md ${badgeStyles[badgeColor]}`}>
            {badgeLabel}
          </span>
        )}
        {aspectRatioHint && (
          <span className="text-[10px] text-slate-300 font-mono bg-black/60 backdrop-blur-md px-2 py-0.5 rounded-md border border-white/10">
            {aspectRatioHint}
          </span>
        )}
      </div>

      {/* Center Play Overlay when paused */}
      {!isPlaying && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/30 backdrop-blur-[2px] transition-all">
          <div className="p-4 rounded-full bg-white/20 text-white backdrop-blur-md border border-white/30 shadow-lg group-hover:scale-110 transition-transform">
            <Play className="w-8 h-8 fill-white translate-x-0.5" />
          </div>
        </div>
      )}

      {/* Bottom Controls */}
      <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between p-1.5 rounded-xl bg-slate-950/70 backdrop-blur-md border border-white/10 opacity-90 group-hover:opacity-100 transition-opacity">
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            togglePlay();
          }}
          className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-white/10"
        >
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
        </button>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={toggleMute}
            className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-white/10"
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={handleFullscreen}
            className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-white/10"
            title="Full screen"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
