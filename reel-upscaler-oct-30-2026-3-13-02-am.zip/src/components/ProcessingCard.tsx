import React from 'react';
import { 
  Sparkles, 
  AlertTriangle, 
  RefreshCw, 
  XCircle, 
  Smartphone, 
  Hourglass,
  Clock,
  Layers,
  Cpu
} from 'lucide-react';
import { EnhancingProgressData } from '../types';

interface ProcessingCardProps {
  progressData: EnhancingProgressData;
  error: string | null;
  onRetry: () => void;
  onCancel: () => void;
}

export const ProcessingCard: React.FC<ProcessingCardProps> = ({
  progressData,
  error,
  onRetry,
  onCancel,
}) => {
  const formatTime = (totalSeconds: number): string => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = Math.floor(totalSeconds % 60);
    return `${mins}m:${secs < 10 ? '0' : ''}${secs}s`;
  };

  const isEnginePhase = progressData.phase === 'engine';

  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-3xl p-5 md:p-6 shadow-2xl backdrop-blur-md space-y-4 animate-fade-in">
      {/* Background Tab / Phone App Switching Warning */}
      <div className="flex items-center gap-2 p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/25 text-amber-200 text-xs">
        <Smartphone className="w-4 h-4 text-amber-400 shrink-0" />
        <span className="leading-tight">
          Export ke dauraan app ko khula rakho — dusre app me jaane par browser kaam rok deta hai.
        </span>
      </div>

      {!error ? (
        <div className="space-y-4">
          {/* Phase 1: Engine Loading */}
          {isEnginePhase ? (
            <div className="space-y-3.5 p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
                    <Cpu className="w-5 h-5 animate-pulse" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-purple-400 block">
                      Phase 1 of 2
                    </span>
                    <h3 className="font-bold text-slate-100 text-sm">
                      Engine load ho raha hai...
                    </h3>
                  </div>
                </div>
                <span className="font-mono font-bold text-base text-purple-400">
                  {progressData.enginePercent}%
                </span>
              </div>

              {/* Progress Bar with RED CANCEL BUTTON NEXT TO IT */}
              <div className="flex items-center gap-2.5">
                <div className="flex-1 bg-slate-800/80 rounded-full h-4 overflow-hidden p-0.5 border border-slate-700/50">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-300"
                    style={{ width: `${Math.max(8, progressData.enginePercent)}%` }}
                  />
                </div>

                {/* Visible Red CANCEL button next to progress bar */}
                <button
                  type="button"
                  onClick={onCancel}
                  className="shrink-0 px-3 py-1.5 rounded-xl font-extrabold text-xs tracking-wider bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white shadow-lg shadow-rose-600/30 border border-rose-400/40 flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                  title="Export cancel karein"
                >
                  <XCircle className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>CANCEL</span>
                </button>
              </div>

              <p className="text-[11px] text-slate-400 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-ping" />
                Browser WebAssembly video processor start ho raha hai...
              </p>
            </div>
          ) : (
            /* Phase 2: Video Enhancing */
            <div className="space-y-3.5 p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-pink-500/20 text-pink-400 border border-pink-500/30">
                    <Sparkles className="w-5 h-5 animate-spin" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-pink-400 block">
                      Phase 2 of 2
                    </span>
                    <h3 className="font-bold text-slate-100 text-sm md:text-base">
                      Enhancing... {progressData.enhancePercent}%
                    </h3>
                  </div>
                </div>
                <span className="font-mono font-bold text-lg text-pink-400">
                  {progressData.enhancePercent}%
                </span>
              </div>

              {/* Progress Bar with RED CANCEL BUTTON NEXT TO IT */}
              <div className="flex items-center gap-2.5">
                <div className="flex-1 bg-slate-800/80 rounded-full h-4 overflow-hidden p-0.5 border border-slate-700/50">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-pink-500 via-rose-500 to-purple-500 transition-all duration-300 shadow-md shadow-pink-500/25"
                    style={{ width: `${Math.max(5, progressData.enhancePercent)}%` }}
                  />
                </div>

                {/* Visible Red CANCEL button next to progress bar */}
                <button
                  type="button"
                  onClick={onCancel}
                  className="shrink-0 px-3 py-1.5 rounded-xl font-extrabold text-xs tracking-wider bg-rose-600 hover:bg-rose-500 active:bg-rose-700 text-white shadow-lg shadow-rose-600/30 border border-rose-400/40 flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                  title="Export cancel karein"
                >
                  <XCircle className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>CANCEL</span>
                </button>
              </div>

              {/* Exact Metrics: Ys processed / Zs total, elapsed Mm:Ss */}
              <div className="flex items-center justify-between text-xs text-slate-300 font-medium">
                <span className="flex items-center gap-1.5 font-mono">
                  <Layers className="w-3.5 h-3.5 text-pink-400" />
                  <span>
                    {progressData.processedSeconds.toFixed(1)}s processed / {progressData.totalSeconds.toFixed(1)}s total
                  </span>
                </span>
                <span className="flex items-center gap-1.5 font-mono text-slate-400">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>elapsed {formatTime(progressData.elapsedSeconds)}</span>
                </span>
              </div>

              {/* 60s Stall Warning: "Ruka nahi hai — phone par slow chal raha hai..." */}
              {progressData.isStalledWarning && (
                <div className="p-3 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-200 text-xs flex items-start gap-2 animate-pulse">
                  <Hourglass className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div className="leading-snug">
                    <p className="font-semibold text-amber-300">Ruka nahi hai</p>
                    <p>Phone par slow chal raha hai, app ko khula rakho, screen band mat karo.</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Secondary Action Link / Tip */}
          <div className="text-center pt-0.5">
            <span className="text-[11px] text-slate-400">
              Kisi bhi waqt CANCEL dabakar process ko safely rok sakte hain
            </span>
          </div>
        </div>
      ) : (
        /* Error State */
        <div className="space-y-4 text-center py-2">
          <div className="inline-flex p-3 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/30">
            <AlertTriangle className="w-7 h-7" />
          </div>
          <div>
            <h4 className="font-bold text-slate-200 text-base mb-1">
              Processing me dikkat aayi
            </h4>
            <p className="text-xs text-amber-200/90 leading-relaxed max-w-sm mx-auto">
              {error}
            </p>
          </div>
          <button
            onClick={onRetry}
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-semibold border border-slate-700 transition-all active:scale-95 cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Dobara Koshish Karein</span>
          </button>
        </div>
      )}
    </div>
  );
};
