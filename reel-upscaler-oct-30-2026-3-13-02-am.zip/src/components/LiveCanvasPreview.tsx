import React, { useRef, useEffect, useState, useCallback } from 'react';
import { 
  ZoomIn, 
  ZoomOut, 
  Columns, 
  SplitSquareVertical, 
  Maximize, 
  Eye, 
  Sparkles,
  Info,
  Activity,
  AlertCircle,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  RotateCcw,
  Volume2,
  VolumeX,
  Repeat,
  Maximize2,
  Minimize2,
  Upload,
  Camera,
  Film
} from 'lucide-react';
import { ViewMode, EnhancementSliders, VideoMetadata } from '../types';
import { WebGLPreviewRenderer } from '../utils/webglPreviewEngine';
import { renderLiveCanvasFrame } from '../utils/canvasFilterEngine';

interface LiveCanvasPreviewProps {
  videoRef: React.RefObject<HTMLVideoElement | null>;
  sliders: EnhancementSliders;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  fps?: number;
  inputVideo: VideoMetadata | null;
  onPlayPause: () => void;
  onSeek: (time: number) => void;
  onImportClick: () => void;
  onRecordClick: () => void;
}

export const LiveCanvasPreview: React.FC<LiveCanvasPreviewProps> = ({
  videoRef,
  sliders,
  isPlaying,
  currentTime,
  duration,
  fps = 30,
  inputVideo,
  onPlayPause,
  onSeek,
  onImportClick,
  onRecordClick,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const previewContainerRef = useRef<HTMLDivElement>(null);
  const webglRendererRef = useRef<WebGLPreviewRenderer | null>(null);
  const fallbackCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const [viewMode, setViewMode] = useState<ViewMode>('fullscreen');
  const [splitPos, setSplitPos] = useState<number>(0.5);
  const [zoom, setZoom] = useState<number>(1.0);
  const [isHoldingOriginal, setIsHoldingOriginal] = useState<boolean>(false);
  const [isDraggingSplit, setIsDraggingSplit] = useState<boolean>(false);

  // Transport & Audio State
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const [isLooping, setIsLooping] = useState<boolean>(true);

  // Fullscreen State (Native + Fallback for iframes/restricted environments)
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [isMaximizedFallback, setIsMaximizedFallback] = useState<boolean>(false);
  const isExpanded = isFullscreen || isMaximizedFallback;

  // Full Quality Check State (renders still frame at source resolution up to 1080p)
  const [isFullQualityCheck, setIsFullQualityCheck] = useState<boolean>(false);

  // Overlay Controls Visibility State (auto-hide after 3s while playing)
  const [showControls, setShowControls] = useState<boolean>(true);
  const controlsTimeoutRef = useRef<any>(null);

  // Tap vs Drag Detection
  const pointerStartPosRef = useRef<{ x: number; y: number } | null>(null);
  const didMoveRef = useRef<boolean>(false);

  // Live FPS & Adaptive Resolution State
  const [liveFps, setLiveFps] = useState<number>(60);
  const [targetWidth, setTargetWidth] = useState<number>(480); // 480p or 360p
  const [fpsProtectionNotice, setFpsProtectionNotice] = useState<string | null>(null);

  const frameCountRef = useRef<number>(0);
  const lastFpsTimestampRef = useRef<number>(performance.now());
  const lowFpsTimerRef = useRef<number>(0);
  const highFpsTimerRef = useRef<number>(0);

  const frameStep = 1 / Math.max(15, Math.min(60, fps));

  // Listen for fullscreen change events (supports Esc key or mobile back button)
  useEffect(() => {
    const handleFsChange = () => {
      const isFs = Boolean(
        document.fullscreenElement ||
        (document as any).webkitFullscreenElement ||
        (document as any).mozFullScreenElement ||
        (document as any).msFullscreenElement
      );
      setIsFullscreen(isFs);
      if (!isFs) {
        setIsMaximizedFallback(false);
      }
    };

    document.addEventListener('fullscreenchange', handleFsChange);
    document.addEventListener('webkitfullscreenchange', handleFsChange);
    document.addEventListener('mozfullscreenchange', handleFsChange);
    document.addEventListener('MSFullscreenChange', handleFsChange);

    return () => {
      document.removeEventListener('fullscreenchange', handleFsChange);
      document.removeEventListener('webkitfullscreenchange', handleFsChange);
      document.removeEventListener('mozfullscreenchange', handleFsChange);
      document.removeEventListener('MSFullscreenChange', handleFsChange);
    };
  }, []);

  // Listen for Escape key to exit fallback maximized mode
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isMaximizedFallback) {
        setIsMaximizedFallback(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isMaximizedFallback]);

  // Auto-hide controls after 3 seconds during playback
  const resetControlsTimeout = useCallback(() => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
      controlsTimeoutRef.current = null;
    }
    if (isPlaying) {
      controlsTimeoutRef.current = setTimeout(() => {
        setShowControls(false);
      }, 3000);
    }
  }, [isPlaying]);

  useEffect(() => {
    if (!isPlaying) {
      setShowControls(true);
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
        controlsTimeoutRef.current = null;
      }
    } else {
      resetControlsTimeout();
    }
    return () => {
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
    };
  }, [isPlaying, resetControlsTimeout]);

  // Initialize WebGL
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const renderer = new WebGLPreviewRenderer(canvas);
    if (renderer.isSupported) {
      webglRendererRef.current = renderer;
    } else {
      console.warn('WebGL not available, using Canvas2D fallback');
      fallbackCanvasRef.current = document.createElement('canvas');
    }

    return () => {
      renderer.destroy();
      webglRendererRef.current = null;
    };
  }, [inputVideo]);

  // Reset Full Quality Check mode whenever playback resumes
  useEffect(() => {
    if (isPlaying) {
      setIsFullQualityCheck(false);
    }
  }, [isPlaying]);

  // Frame rendering loop (GPU accelerated with strict contain logic)
  const drawFrame = useCallback(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.readyState < 2) return;

    const isStillFrame = !isPlaying || isFullQualityCheck;
    const aspect = (video.videoHeight || 16) / (video.videoWidth || 9);
    let renderW: number;
    let renderH: number;

    if (isStillFrame) {
      // 1. PAUSED / FULL QUALITY CHECK: Full source resolution (up to 1080p edge)
      const vidW = video.videoWidth || 1080;
      const vidH = video.videoHeight || 1920;
      if (vidW <= vidH) {
        // Portrait or square: width up to 1080
        renderW = Math.min(1080, vidW);
        renderH = Math.round(renderW * (vidH / vidW));
      } else {
        // Landscape: height up to 1080
        renderH = Math.min(1080, vidH);
        renderW = Math.round(renderH * (vidW / vidH));
      }
    } else {
      // 2. PLAYING: Smooth 480p / 360p proxy for 60 FPS
      renderW = targetWidth;
      renderH = Math.round(renderW * aspect);

      // Track real FPS & adaptive proxy logic only during active playback
      frameCountRef.current++;
      const now = performance.now();
      const elapsed = now - lastFpsTimestampRef.current;

      if (elapsed >= 500) {
        const currentFps = Math.round((frameCountRef.current * 1000) / elapsed);
        setLiveFps(currentFps);
        frameCountRef.current = 0;
        lastFpsTimestampRef.current = now;

        // Automatic FPS protection logic during playback
        if (currentFps < 24) {
          lowFpsTimerRef.current += elapsed;
          highFpsTimerRef.current = 0;
          if (lowFpsTimerRef.current >= 3000 && targetWidth > 360) {
            setTargetWidth(360);
            setFpsProtectionNotice(
              'Preview quality auto kam ki gayi hai taaki smooth chale — final export par koi asar nahi.'
            );
          }
        } else if (currentFps >= 50) {
          highFpsTimerRef.current += elapsed;
          lowFpsTimerRef.current = 0;
          if (highFpsTimerRef.current >= 5000 && targetWidth < 480) {
            setTargetWidth(480);
            setFpsProtectionNotice(null);
          }
        } else {
          lowFpsTimerRef.current = 0;
          highFpsTimerRef.current = 0;
        }
      }
    }

    // Fast GPU WebGL Path
    if (webglRendererRef.current && webglRendererRef.current.isSupported) {
      webglRendererRef.current.render(
        video,
        renderW,
        renderH,
        viewMode,
        splitPos,
        isHoldingOriginal,
        sliders,
        zoom
      );
    } else {
      // Fallback Canvas2D path
      if (!fallbackCanvasRef.current) fallbackCanvasRef.current = document.createElement('canvas');
      renderLiveCanvasFrame({
        video,
        targetCanvas: canvas,
        offscreenCanvas: fallbackCanvasRef.current,
        viewMode,
        splitPosition: splitPos,
        isComparingOriginal: isHoldingOriginal,
        sliders,
        zoom,
        isFullQuality: isStillFrame,
      });
    }
  }, [videoRef, targetWidth, viewMode, splitPos, isHoldingOriginal, sliders, zoom, isPlaying, isFullQualityCheck]);

  // Sync with requestVideoFrameCallback
  useEffect(() => {
    let animId: number;
    let videoCallbackId: number | null = null;
    let isActive = true;

    const video = videoRef.current;

    const onFrame = () => {
      if (!isActive) return;
      drawFrame();

      if (video && 'requestVideoFrameCallback' in video && typeof (video as any).requestVideoFrameCallback === 'function') {
        videoCallbackId = (video as any).requestVideoFrameCallback(onFrame);
      } else if (isPlaying) {
        animId = requestAnimationFrame(onFrame);
      }
    };

    if (video && 'requestVideoFrameCallback' in video && typeof (video as any).requestVideoFrameCallback === 'function') {
      videoCallbackId = (video as any).requestVideoFrameCallback(onFrame);
    } else {
      onFrame();
      if (isPlaying) {
        animId = requestAnimationFrame(onFrame);
      }
    }

    return () => {
      isActive = false;
      if (animId) cancelAnimationFrame(animId);
      if (videoCallbackId !== null && video && 'cancelVideoFrameCallback' in video) {
        try {
          (video as any).cancelVideoFrameCallback(videoCallbackId);
        } catch {}
      }
    };
  }, [isPlaying, drawFrame, currentTime]);

  // Time formatter MM:SS.t
  const formatTime = (timeInSeconds: number) => {
    if (isNaN(timeInSeconds) || timeInSeconds < 0) return '00:00.0';
    const mins = Math.floor(timeInSeconds / 60);
    const secs = Math.floor(timeInSeconds % 60);
    const tenths = Math.floor((timeInSeconds % 1) * 10);
    return `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}.${tenths}`;
  };

  // Zoom handlers
  const handleZoomIn = () => setZoom((z) => Math.min(2.0, parseFloat((z + 0.25).toFixed(2))));
  const handleZoomOut = () => setZoom((z) => Math.max(0.5, parseFloat((z - 0.25).toFixed(2))));
  const handleZoomReset = () => setZoom(1.0);

  // Transport Handlers
  const handleStepBack = () => {
    const next = Math.max(0, currentTime - frameStep);
    onSeek(next);
  };

  const handleStepForward = () => {
    const next = Math.min(duration, currentTime + frameStep);
    onSeek(next);
  };

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    resetControlsTimeout();
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const toggleLoop = (e: React.MouseEvent) => {
    e.stopPropagation();
    resetControlsTimeout();
    if (videoRef.current) {
      videoRef.current.loop = !isLooping;
      setIsLooping(!isLooping);
    }
  };

  // Pointer & Drag Handlers on Preview Container
  const handleContainerPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    resetControlsTimeout();
    pointerStartPosRef.current = { x: e.clientX, y: e.clientY };
    didMoveRef.current = false;
    if (viewMode === 'split') {
      setIsDraggingSplit(true);
      updateSplitFromPointer(e);
    }
  };

  const handleContainerPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    resetControlsTimeout();
    if (pointerStartPosRef.current) {
      const dx = Math.abs(e.clientX - pointerStartPosRef.current.x);
      const dy = Math.abs(e.clientY - pointerStartPosRef.current.y);
      if (dx > 6 || dy > 6) {
        didMoveRef.current = true;
      }
    }
    if (isDraggingSplit && viewMode === 'split') {
      updateSplitFromPointer(e);
    }
  };

  const handleContainerPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    setIsDraggingSplit(false);
    const target = e.target as HTMLElement;
    const isInteractive = target.closest('button') || target.closest('input');
    // If user tapped without dragging, toggle play/pause
    if (!didMoveRef.current && !isInteractive) {
      if (isFullQualityCheck) {
        setIsFullQualityCheck(false);
      }
      onPlayPause();
    }
    pointerStartPosRef.current = null;
    didMoveRef.current = false;
  };

  const updateSplitFromPointer = (e: React.PointerEvent<HTMLElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const ratio = Math.max(0.05, Math.min(0.95, x / rect.width));
    setSplitPos(ratio);
    drawFrame();
  };

  // Fullscreen Handler (Seamless playback & contain logic with iframe fallback)
  const handleFullscreenToggle = async (e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    resetControlsTimeout();

    const container = previewContainerRef.current;
    if (!container) return;

    if (isExpanded) {
      // Exit native fullscreen if active
      if (
        document.fullscreenElement ||
        (document as any).webkitFullscreenElement ||
        (document as any).mozFullScreenElement ||
        (document as any).msFullscreenElement
      ) {
        try {
          if (document.exitFullscreen) {
            await document.exitFullscreen();
          } else if ((document as any).webkitExitFullscreen) {
            await (document as any).webkitExitFullscreen();
          } else if ((document as any).mozCancelFullScreen) {
            await (document as any).mozCancelFullScreen();
          } else if ((document as any).msExitFullscreen) {
            await (document as any).msExitFullscreen();
          }
        } catch (err) {
          console.warn('Exit fullscreen failed:', err);
        }
      }
      setIsMaximizedFallback(false);
    } else {
      let nativeSuccess = false;
      try {
        if (container.requestFullscreen) {
          await container.requestFullscreen();
          nativeSuccess = true;
        } else if ((container as any).webkitRequestFullscreen) {
          await (container as any).webkitRequestFullscreen();
          nativeSuccess = true;
        } else if ((container as any).mozRequestFullScreen) {
          await (container as any).mozRequestFullScreen();
          nativeSuccess = true;
        } else if ((container as any).msRequestFullscreen) {
          await (container as any).msRequestFullscreen();
          nativeSuccess = true;
        }
      } catch (err) {
        console.warn('Native requestFullscreen blocked or unsupported (iframe constraint), using in-page maximized fallback:', err);
        nativeSuccess = false;
      }

      if (!nativeSuccess) {
        setIsMaximizedFallback(true);
      }

      // REQUIREMENT: Video must play in fullscreen
      // If paused when tapped, start playing from current position
      // If already playing, keep playing seamlessly
      if (videoRef.current && videoRef.current.paused) {
        try {
          await videoRef.current.play();
          onPlayPause();
        } catch (err) {
          console.warn('Fullscreen play start:', err);
        }
      }
    }
  };

  // If no video is chosen yet, display clear Import prompt inside the preview area
  if (!inputVideo) {
    return (
      <div className="relative w-full max-w-[280px] mx-auto rounded-3xl overflow-hidden bg-slate-950 border-2 border-dashed border-slate-800 shadow-2xl aspect-[9/16] max-h-[380px] flex flex-col items-center justify-center p-6 text-center space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-pink-500/20 via-purple-500/20 to-blue-500/20 border border-pink-500/30 flex items-center justify-center shadow-lg shadow-pink-500/10">
          <Film className="w-8 h-8 text-pink-400" />
        </div>

        <div className="space-y-1">
          <h3 className="text-sm font-bold text-white">Koi video select nahi hai</h3>
          <p className="text-[11px] text-slate-400">
            Reel ya clip chunein ya camera se record karein
          </p>
        </div>

        <div className="flex flex-col gap-2 w-full pt-1">
          <button
            type="button"
            onClick={onImportClick}
            className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-pink-600/30 active:scale-95 transition-all cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            <span>Import Reel / Video</span>
          </button>

          <button
            type="button"
            onClick={onRecordClick}
            className="w-full py-2.5 px-4 rounded-2xl bg-slate-900 hover:bg-slate-850 border border-slate-700/80 text-pink-200 font-semibold text-xs flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer"
          >
            <Camera className="w-3.5 h-3.5 text-pink-400" />
            <span>Record Clip</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full space-y-2.5">
      {/* 1. Four View Mode Tabs (When in normal windowed view) */}
      {!isExpanded && (
        <div className="grid grid-cols-4 gap-1 p-1 bg-slate-950/70 border border-slate-800 rounded-2xl text-[11px] font-semibold">
          <button
            type="button"
            onClick={() => setViewMode('fullscreen')}
            className={`py-2 px-1 rounded-xl flex items-center justify-center gap-1 transition-all ${
              viewMode === 'fullscreen'
                ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <Maximize className="w-3 h-3 shrink-0" />
            <span className="truncate">Enhanced</span>
          </button>

          <button
            type="button"
            onClick={() => setViewMode('split')}
            className={`py-2 px-1 rounded-xl flex items-center justify-center gap-1 transition-all ${
              viewMode === 'split'
                ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <SplitSquareVertical className="w-3 h-3 shrink-0" />
            <span className="truncate">Split</span>
          </button>

          <button
            type="button"
            onClick={() => setViewMode('side-by-side')}
            className={`py-2 px-1 rounded-xl flex items-center justify-center gap-1 transition-all ${
              viewMode === 'side-by-side'
                ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <Columns className="w-3 h-3 shrink-0" />
            <span className="truncate">Side-by-Side</span>
          </button>

          <button
            type="button"
            onClick={() => setViewMode('original')}
            className={`py-2 px-1 rounded-xl flex items-center justify-center gap-1 transition-all ${
              viewMode === 'original'
                ? 'bg-gradient-to-r from-pink-600 to-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <Eye className="w-3 h-3 shrink-0" />
            <span className="truncate">Original</span>
          </button>
        </div>
      )}

      {/* 2. LIVE PREVIEW CANVAS AREA WITH ALL OVERLAY CONTROLS */}
      <div 
        ref={previewContainerRef}
        className={`relative group mx-auto bg-black flex items-center justify-center select-none overflow-hidden touch-none transition-all ${
          isExpanded
            ? 'fixed inset-0 z-50 w-screen h-screen max-w-none max-h-none rounded-none border-none aspect-auto'
            : 'w-full max-w-[280px] rounded-3xl border border-slate-800 shadow-2xl aspect-[9/16] max-h-[380px]'
        }`}
        onPointerDown={handleContainerPointerDown}
        onPointerMove={handleContainerPointerMove}
        onPointerUp={handleContainerPointerUp}
        onPointerCancel={handleContainerPointerUp}
      >
        <canvas
          ref={canvasRef}
          width={targetWidth}
          height={Math.round(targetWidth * ((videoRef.current?.videoHeight || 16) / (videoRef.current?.videoWidth || 9)))}
          className="w-full h-full object-contain cursor-crosshair select-none"
        />

        {/* Dedicated Top-Right Fullscreen / Maximize Button (Always visible, z-30, min 44x44 touch target) */}
        <button
          type="button"
          onClick={handleFullscreenToggle}
          className="absolute top-2.5 right-2.5 z-30 min-w-[44px] min-h-[44px] w-11 h-11 rounded-xl bg-slate-950/85 hover:bg-slate-900 border border-white/20 text-white shadow-xl flex items-center justify-center pointer-events-auto active:scale-95 transition-all cursor-pointer"
          title={isExpanded ? 'Exit Fullscreen / Minimize (Esc)' : 'Fullscreen / Maximize Preview'}
          aria-label={isExpanded ? 'Exit Fullscreen' : 'Enter Fullscreen'}
        >
          {isExpanded ? (
            <Minimize2 className="w-5 h-5 text-pink-400" />
          ) : (
            <Maximize2 className="w-5 h-5 text-slate-200 hover:text-white" />
          )}
        </button>

        {/* Draggable Divider Overlay for Split Mode */}
        {viewMode === 'split' && (
          <div
            className="absolute top-0 bottom-0 pointer-events-none flex flex-col items-center justify-center z-20"
            style={{ left: `${splitPos * 100}%`, transform: 'translateX(-50%)' }}
          >
            <div className="w-0.5 h-full bg-pink-500 shadow-[0_0_8px_rgba(236,72,153,0.8)]" />
            <div className="absolute top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-pink-600 border-2 border-white shadow-lg flex items-center justify-center text-white text-[10px] font-bold">
              ◀▶
            </div>
          </div>
        )}

        {/* Floating View Mode Switcher in Fullscreen */}
        {isExpanded && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-1 p-1 bg-slate-950/80 backdrop-blur-md border border-white/20 rounded-2xl z-30 shadow-2xl">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setViewMode('fullscreen');
              }}
              className={`px-2.5 py-1 rounded-xl text-xs font-semibold ${
                viewMode === 'fullscreen' ? 'bg-pink-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Enhanced
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setViewMode('split');
              }}
              className={`px-2.5 py-1 rounded-xl text-xs font-semibold ${
                viewMode === 'split' ? 'bg-pink-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Split
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setViewMode('side-by-side');
              }}
              className={`px-2.5 py-1 rounded-xl text-xs font-semibold ${
                viewMode === 'side-by-side' ? 'bg-pink-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Side-by-Side
            </button>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setViewMode('original');
              }}
              className={`px-2.5 py-1 rounded-xl text-xs font-semibold ${
                viewMode === 'original' ? 'bg-pink-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Original
            </button>
          </div>
        )}

        {/* Top Overlay: View Mode Badge & Live FPS / Full Quality Meter */}
        <div 
          className={`absolute top-3 left-3 right-16 flex items-center justify-between pointer-events-none z-10 transition-opacity duration-300 ${
            !isPlaying || showControls ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <div className="flex items-center gap-1.5 flex-wrap">
            {(!isPlaying || isFullQualityCheck) && (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-pink-500/25 text-pink-200 border border-pink-500/40 backdrop-blur-md flex items-center gap-1 shadow-md animate-fade-in">
                <Sparkles className="w-3 h-3 text-pink-400" />
                Full Quality Frame
              </span>
            )}
            {viewMode === 'fullscreen' && !isHoldingOriginal && (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-900/80 text-white border border-white/20 backdrop-blur-md flex items-center gap-1 shadow-sm">
                <Maximize className="w-3 h-3 text-pink-400" />
                Enhanced
              </span>
            )}
            {viewMode === 'split' && !isHoldingOriginal && (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-900/80 text-white border border-white/20 backdrop-blur-md">
                Original ◀ Divider ▶ Enhanced
              </span>
            )}
            {viewMode === 'side-by-side' && !isHoldingOriginal && (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-900/80 text-white border border-white/20 backdrop-blur-md">
                Left: Orig | Right: Enh
              </span>
            )}
            {(viewMode === 'original' || isHoldingOriginal) && (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 backdrop-blur-md flex items-center gap-1 shadow-sm">
                <Eye className="w-3 h-3 text-amber-400" />
                Original View
              </span>
            )}
          </div>

          {/* Live Preview FPS / Full Quality Meter */}
          <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-950/80 border backdrop-blur-md flex items-center gap-1 shadow-sm shrink-0 ${
            (!isPlaying || isFullQualityCheck)
              ? 'text-pink-300 border-pink-500/40'
              : 'text-emerald-400 border-emerald-500/30'
          }`}>
            {(!isPlaying || isFullQualityCheck) ? (
              <>
                <Sparkles className="w-3 h-3 text-pink-400" />
                <span>Full Quality Frame</span>
              </>
            ) : (
              <>
                <Activity className="w-3 h-3 text-emerald-400" />
                <span>{liveFps} FPS</span>
              </>
            )}
          </span>
        </div>

        {/* Center Overlay: Large Play / Pause Button */}
        <div
          className={`absolute inset-0 flex items-center justify-center pointer-events-none z-20 transition-opacity duration-300 ${
            !isPlaying || showControls ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              resetControlsTimeout();
              if (isFullQualityCheck) {
                setIsFullQualityCheck(false);
              }
              onPlayPause();
            }}
            className="pointer-events-auto p-4 sm:p-5 rounded-3xl bg-slate-950/75 hover:bg-slate-900/90 text-white border border-white/20 shadow-2xl backdrop-blur-md active:scale-90 transition-all cursor-pointer flex items-center justify-center"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-7 h-7 sm:w-8 sm:h-8 fill-white text-white" />
            ) : (
              <Play className="w-7 h-7 sm:w-8 sm:h-8 fill-white text-white translate-x-0.5" />
            )}
          </button>
        </div>

        {/* Floating Zoom Control Pill (Dedicated Bottom-Right position above transport bar — never clipped or hidden) */}
        <div
          className={`absolute bottom-[76px] right-2.5 z-20 transition-opacity duration-300 ${
            !isPlaying || showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
        >
          <div className="flex items-center gap-0.5 bg-slate-950/90 backdrop-blur-md rounded-xl p-1 border border-white/20 shadow-xl pointer-events-auto">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                resetControlsTimeout();
                handleZoomOut();
              }}
              className="min-w-[30px] min-h-[30px] w-7 h-7 flex items-center justify-center text-slate-300 hover:text-white rounded-lg hover:bg-white/10 active:scale-90 transition-all cursor-pointer"
              title="Zoom Out (Min 50%)"
              aria-label="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                resetControlsTimeout();
                handleZoomReset();
              }}
              className="text-[10px] font-mono font-bold text-slate-200 hover:text-pink-400 px-1.5 py-1 rounded hover:bg-white/5 active:scale-95 transition-all cursor-pointer select-none"
              title="Click to reset zoom to 100% (Fit)"
              aria-label="Reset Zoom"
            >
              {Math.round(zoom * 100)}%
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                resetControlsTimeout();
                handleZoomIn();
              }}
              className="min-w-[30px] min-h-[30px] w-7 h-7 flex items-center justify-center text-slate-300 hover:text-white rounded-lg hover:bg-white/10 active:scale-90 transition-all cursor-pointer"
              title="Zoom In (Max 200%)"
              aria-label="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Bottom Overlay: Timeline Scrubber + Transport Controls Bar */}
        <div
          className={`absolute bottom-0 left-0 right-0 p-2 sm:p-3 z-20 transition-opacity duration-300 ${
            !isPlaying || showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'
          }`}
        >
          <div className="bg-slate-950/85 backdrop-blur-md rounded-2xl border border-white/10 p-2 space-y-1.5 shadow-2xl">
            {/* Timeline Scrubber */}
            <div className="flex items-center gap-2 text-[10px] font-mono text-slate-300">
              <span className="text-pink-400 font-bold shrink-0">{formatTime(currentTime)}</span>
              <input
                type="range"
                min={0}
                max={Math.max(0.1, duration)}
                step={0.01}
                value={currentTime}
                onChange={(e) => {
                  e.stopPropagation();
                  resetControlsTimeout();
                  onSeek(parseFloat(e.target.value));
                }}
                onClick={(e) => e.stopPropagation()}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-pink-500"
              />
              <span className="text-slate-400 font-medium shrink-0">{formatTime(duration)}</span>
            </div>

            {/* Transport Button Row */}
            <div className="flex items-center justify-between gap-1 pt-0.5">
              {/* Left Transport: Reset, Prev Frame, Next Frame, Loop, Mute */}
              <div className="flex items-center gap-0.5 sm:gap-1">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    resetControlsTimeout();
                    onSeek(0);
                  }}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
                  title="Reset to 0:00"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    resetControlsTimeout();
                    handleStepBack();
                  }}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
                  title="Previous Frame"
                >
                  <SkipBack className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    resetControlsTimeout();
                    handleStepForward();
                  }}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
                  title="Next Frame"
                >
                  <SkipForward className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={toggleLoop}
                  className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                    isLooping
                      ? 'text-pink-400 bg-pink-500/20'
                      : 'text-slate-400 hover:text-white hover:bg-white/10'
                  }`}
                  title={isLooping ? 'Loop: ON' : 'Loop: OFF'}
                >
                  <Repeat className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={toggleMute}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
                  title={isMuted ? 'Unmute' : 'Mute'}
                >
                  {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                </button>
              </div>

              {/* Right Transport: Full Quality Check, Hold Original */}
              <div className="flex items-center gap-1 shrink-0">
                {/* Full Quality Check Button */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    resetControlsTimeout();
                    if (!isFullQualityCheck) {
                      if (isPlaying) {
                        onPlayPause();
                      }
                      setIsFullQualityCheck(true);
                    } else {
                      setIsFullQualityCheck(false);
                    }
                  }}
                  className={`px-1.5 py-1 rounded-lg text-[9px] font-bold flex items-center gap-1 select-none active:scale-95 transition-all cursor-pointer ${
                    (!isPlaying || isFullQualityCheck)
                      ? 'bg-pink-600/30 text-pink-300 border border-pink-500/50 shadow-sm shadow-pink-500/20'
                      : 'bg-slate-900 text-slate-300 hover:text-white border border-white/10'
                  }`}
                  title="Check Full Quality Frame (Sharpness test)"
                >
                  <Sparkles className={`w-3 h-3 ${(!isPlaying || isFullQualityCheck) ? 'text-pink-400' : 'text-slate-400'}`} />
                  <span className="hidden sm:inline">{isFullQualityCheck ? 'Full Quality Frame ✓' : 'Full Quality Check'}</span>
                  <span className="sm:hidden">{isFullQualityCheck ? 'Full Res ✓' : 'Full Res'}</span>
                </button>

                <button
                  type="button"
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    setIsHoldingOriginal(true);
                  }}
                  onPointerUp={(e) => {
                    e.stopPropagation();
                    setIsHoldingOriginal(false);
                  }}
                  onPointerLeave={() => setIsHoldingOriginal(false)}
                  className="px-1.5 py-1 rounded-lg bg-slate-900 text-slate-300 hover:text-amber-300 border border-white/10 text-[9px] font-semibold flex items-center gap-1 select-none active:scale-95 transition-all cursor-pointer"
                  title="Hold to see original"
                >
                  <Eye className="w-3 h-3 text-amber-400" />
                  <span className="hidden sm:inline">Hold</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Adaptive FPS Notification Banner */}
      {fpsProtectionNotice && (
        <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-200 text-xs flex items-center gap-2 animate-fade-in">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>{fpsProtectionNotice}</span>
        </div>
      )}

      {/* Speed & Resolution Notice */}
      <div className="text-center">
        {(!isPlaying || isFullQualityCheck) ? (
          <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-pink-300 bg-pink-500/10 border border-pink-500/25 px-3 py-1 rounded-full shadow-sm animate-fade-in">
            <Sparkles className="w-3.5 h-3.5 text-pink-400 shrink-0" />
            Full Quality Frame — asli sharpness yahi dikhegi
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 text-[10px] text-slate-400">
            <Info className="w-3 h-3 text-slate-400 shrink-0" />
            WebGL GPU acceleration active ({targetWidth}p proxy) — final export full quality hoga
          </span>
        )}
      </div>
    </div>
  );
};
