import React, { useState } from 'react';
import { 
  Smartphone, 
  Download, 
  CheckCircle2, 
  X, 
  Share2, 
  Copy, 
  Sparkles, 
  ShieldCheck,
  Check,
  HelpCircle
} from 'lucide-react';

interface InstallApkModalProps {
  isOpen: boolean;
  onClose: () => void;
  deferredPrompt: any;
  isStandalone: boolean;
  onInstallPromptSuccess: () => void;
}

export const InstallApkModal: React.FC<InstallApkModalProps> = ({
  isOpen,
  onClose,
  deferredPrompt,
  isStandalone,
  onInstallPromptSuccess,
}) => {
  const [copied, setCopied] = useState(false);
  const [installing, setInstalling] = useState(false);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      setInstalling(true);
      try {
        await deferredPrompt.prompt();
        const choiceResult = await deferredPrompt.userChoice;
        if (choiceResult.outcome === 'accepted') {
          onInstallPromptSuccess();
          onClose();
        }
      } catch (err) {
        console.warn('Install prompt error:', err);
      } finally {
        setInstalling(false);
      }
    }
  };

  const handleCopyLink = () => {
    const url = window.location.href;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(url).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
      }).catch(() => {});
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl text-slate-100 my-auto space-y-4">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800/60 hover:bg-slate-800 transition-colors cursor-pointer"
          title="Band karo"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Badge */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-tr from-pink-500/20 via-purple-500/20 to-blue-500/20 border border-pink-500/30 rounded-2xl text-pink-400 shadow-md shadow-pink-500/10">
            <Smartphone className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-xl font-extrabold tracking-tight text-white flex items-center gap-2">
              Install Android APK
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 font-bold uppercase">
                Direct
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Bina kisi 3rd-party website ke standalone phone app
            </p>
          </div>
        </div>

        {/* Already Installed State */}
        {isStandalone ? (
          <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-800/50 space-y-2 text-center animate-fade-in">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <h3 className="font-bold text-sm text-white">App Pehle Se Installed Hai ✓</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Aap already standalone installed app chala rahe hain. Saari processing 100% offline aur direct phone par chalegi.
            </p>
          </div>
        ) : deferredPrompt ? (
          /* Native 1-Tap Prompt Available */
          <div className="space-y-3">
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 text-xs text-slate-300 space-y-1.5 leading-relaxed">
              <p className="font-semibold text-pink-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-pink-400" />
                Phone Par Direct Install Ready
              </p>
              <p>
                Neeche "Install APK Now" dabayein. Android system direct APK create karke home screen par add kar dega.
              </p>
            </div>

            <button
              onClick={handleInstallClick}
              disabled={installing}
              className="w-full py-4 px-6 rounded-2xl font-bold text-base bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white shadow-lg shadow-pink-600/30 active:scale-[0.98] transition-all flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-70"
            >
              <Download className="w-5 h-5 stroke-[2.5]" />
              <span>{installing ? 'Installing...' : 'INSTALL APK NOW'}</span>
            </button>
          </div>
        ) : (
          /* Publish & Install Guide */
          <div className="space-y-3.5">
            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-3 text-xs leading-relaxed">
              <h4 className="font-bold text-sm text-white flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-pink-400" />
                Publish ke baad phone me install kaise karein:
              </h4>

              <div className="space-y-2 text-slate-300">
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/40 text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                    1
                  </span>
                  <span>
                    AI Studio me <b>Publish</b> button dabayein taaki public link generate ho jaye.
                  </span>
                </div>

                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/40 text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                    2
                  </span>
                  <span>
                    Us link ko apne Android phone ke <b>Chrome browser</b> me open karein.
                  </span>
                </div>

                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/40 text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                    3
                  </span>
                  <span>
                    Wahan <b>"INSTALL APK"</b> banner par tap karein, ya Chrome menu (⋮) me <b>"Install app / Add to Home screen"</b> dabayein.
                  </span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/20 text-[11px] text-purple-200">
                ✓ Yeh app Android WebAPK standard follow karti hai — phone me direct real standalone app ki tarah save hoti hai bina kisi 3rd party tool ke!
              </div>
            </div>

            {/* Copy Link Button */}
            <button
              onClick={handleCopyLink}
              className="w-full py-3.5 px-4 rounded-2xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-xs font-bold text-white flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-400">Link Copied! Phone me share karein</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-pink-400" />
                  <span>App Link Copy Karein</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* Feature Highlights */}
        <div className="pt-1 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            100% Local & Safe
          </span>
          <span>Zero Server Upload</span>
          <span>No Watermark</span>
        </div>
      </div>
    </div>
  );
};
