import { EnhancementSliders, ViewMode } from '../types';

/**
 * High-performance client-side image filter engine for real-time live preview
 */
export function applyEnhancementToImageData(
  sourceData: ImageData,
  targetData: ImageData,
  sliders: EnhancementSliders,
  width: number,
  height: number
) {
  const src = sourceData.data;
  const dst = targetData.data;
  const len = src.length;
  const totalPixels = width * height;

  const sharpnessWeight = (sliders.neuralSharpness / 100) * 1.5;
  const denoiseWeight = (sliders.denoise / 100) * 0.8;
  const detailWeight = (sliders.detailRecovery / 100) * 1.2;
  const contrastFactor = 1 + (sliders.dynamicContrast / 100) * 0.45;
  const vibranceFactor = (sliders.vibrance / 100) * 0.75;
  const ditherStrength = (sliders.antiBanding / 100) * 12;
  const faceProtect = sliders.faceProtection;

  // Pre-calculate contrast curve lookup table for high performance
  const contrastLUT = new Uint8ClampedArray(256);
  for (let i = 0; i < 256; i++) {
    // Lift dark shadows smoothly without clipping highlights (CLAHE style)
    const norm = i / 255;
    // S-curve with shadow lift
    const shadowLift = Math.pow(norm, 0.82);
    const contrasted = (shadowLift - 0.5) * contrastFactor + 0.5;
    contrastLUT[i] = Math.max(0, Math.min(255, Math.round(contrasted * 255)));
  }

  // Pre-calculate luma buffer for spatial operations
  const luma = new Float32Array(totalPixels);
  for (let i = 0; i < len; i += 4) {
    luma[i / 4] = 0.299 * src[i] + 0.587 * src[i + 1] + 0.114 * src[i + 2];
  }

  // 1-pixel step convolution for sharpness & denoise
  for (let y = 0; y < height; y++) {
    const yOffset = y * width;
    const yTop = y > 0 ? (y - 1) * width : yOffset;
    const yBottom = y < height - 1 ? (y + 1) * width : yOffset;

    for (let x = 0; x < width; x++) {
      const idx = yOffset + x;
      const pIdx = idx * 4;

      const r = src[pIdx];
      const g = src[pIdx + 1];
      const b = src[pIdx + 2];
      const a = src[pIdx + 3];

      const currentLuma = luma[idx];
      const xLeft = x > 0 ? idx - 1 : idx;
      const xRight = x < width - 1 ? idx + 1 : idx;

      // Check skin tone (Face & Skin Protection heuristic)
      let isSkin = false;
      if (faceProtect) {
        const maxVal = Math.max(r, g, b);
        const minVal = Math.min(r, g, b);
        if (r > 95 && g > 40 && b > 20 && maxVal - minVal > 15 && Math.abs(r - g) > 15 && r > g && r > b) {
          isSkin = true;
        }
      }

      // 4-neighbor average
      const lumaTop = luma[yTop + x];
      const lumaBottom = luma[yBottom + x];
      const lumaLeft = luma[xLeft];
      const lumaRight = luma[xRight];
      const neighborAvg = (lumaTop + lumaBottom + lumaLeft + lumaRight) * 0.25;

      // 1. Neural Sharpness (Laplacian with halo-suppression gate)
      const laplacian = 4 * currentLuma - lumaTop - lumaBottom - lumaLeft - lumaRight;
      // Halo suppression: clamp overshoot
      const haloClampedLap = Math.max(-28, Math.min(28, laplacian));
      const sharpBoost = haloClampedLap * (isSkin ? sharpnessWeight * 0.3 : sharpnessWeight);

      // 2. Denoise (Edge-preserving bilateral smoothing)
      let smoothedLuma = currentLuma;
      const edgeDiff = Math.abs(currentLuma - neighborAvg);
      if (edgeDiff < 20 || (isSkin && edgeDiff < 35)) {
        // Flat region or skin: smooth
        const blend = isSkin ? Math.min(0.65, denoiseWeight * 1.3) : Math.min(0.5, denoiseWeight);
        smoothedLuma = currentLuma * (1 - blend) + neighborAvg * blend;
      }

      // 3. Detail & Texture Recovery (high-frequency detail)
      const detailDelta = (currentLuma - neighborAvg) * (isSkin ? detailWeight * 0.2 : detailWeight);

      // Combine luma adjustments
      const enhancedLuma = smoothedLuma + sharpBoost + detailDelta;
      const lumaRatio = currentLuma > 4 ? enhancedLuma / currentLuma : 1;

      // Apply to RGB
      let outR = r * lumaRatio;
      let outG = g * lumaRatio;
      let outB = b * lumaRatio;

      // 4. Dynamic Contrast Lift (LUT)
      const lumIdx = Math.max(0, Math.min(255, Math.round(enhancedLuma)));
      const contrastGain = currentLuma > 0 ? contrastLUT[lumIdx] / Math.max(1, currentLuma) : 1;
      outR = outR * 0.4 + outR * contrastGain * 0.6;
      outG = outG * 0.4 + outG * contrastGain * 0.6;
      outB = outB * 0.4 + outB * contrastGain * 0.6;

      // 5. Vibrance (Gamut Lift)
      const maxC = Math.max(outR, outG, outB);
      const minC = Math.min(outR, outG, outB);
      const currentSat = maxC === 0 ? 0 : (maxC - minC) / maxC;
      // Boost muted colors more, protect already saturated & skin pixels
      const satWeight = isSkin ? vibranceFactor * 0.25 : (1 - currentSat) * vibranceFactor;
      const grayVal = 0.299 * outR + 0.587 * outG + 0.114 * outB;
      outR = outR + (outR - grayVal) * satWeight;
      outG = outG + (outG - grayVal) * satWeight;
      outB = outB + (outB - grayVal) * satWeight;

      // 6. Anti-Banding Dither (fine triangular noise grain)
      if (ditherStrength > 0) {
        // Fast pseudo-random high frequency noise based on coordinates
        const n = (((x * 12.9898 + y * 78.233) * 43758.5453) % 1) - 0.5;
        const dither = n * ditherStrength;
        outR += dither;
        outG += dither;
        outB += dither;
      }

      dst[pIdx] = Math.max(0, Math.min(255, Math.round(outR)));
      dst[pIdx + 1] = Math.max(0, Math.min(255, Math.round(outG)));
      dst[pIdx + 2] = Math.max(0, Math.min(255, Math.round(outB)));
      dst[pIdx + 3] = a;
    }
  }
}

export interface RenderCanvasPreviewOptions {
  video: HTMLVideoElement;
  targetCanvas: HTMLCanvasElement;
  offscreenCanvas: HTMLCanvasElement;
  viewMode: ViewMode;
  splitPosition: number; // 0 to 1
  isComparingOriginal: boolean;
  sliders: EnhancementSliders;
  zoom: number; // 0.5 to 2.0
  isFullQuality?: boolean;
}

export function renderLiveCanvasFrame({
  video,
  targetCanvas,
  offscreenCanvas,
  viewMode,
  splitPosition,
  isComparingOriginal,
  sliders,
  zoom,
  isFullQuality = false,
}: RenderCanvasPreviewOptions) {
  if (!video || video.readyState < 2) return;

  const ctx = targetCanvas.getContext('2d');
  const offCtx = offscreenCanvas.getContext('2d', { willReadFrequently: true });
  if (!ctx || !offCtx) return;

  // Render resolution: full (up to 1080p) if paused/fullQuality, else 360-540px for speed
  const maxW = isFullQuality ? 1080 : 540;
  const renderW = Math.min(maxW, video.videoWidth || 360);
  const renderH = Math.round((video.videoHeight / (video.videoWidth || 1)) * renderW) || 640;

  if (offscreenCanvas.width !== renderW || offscreenCanvas.height !== renderH) {
    offscreenCanvas.width = renderW;
    offscreenCanvas.height = renderH;
  }

  // Draw original video frame to offscreen
  offCtx.drawImage(video, 0, 0, renderW, renderH);

  // Dimensions for contain calculations
  const tW = targetCanvas.width;
  const tH = targetCanvas.height;
  const vidW = renderW;
  const vidH = renderH;

  // If view is 'original' or compare button is pressed, draw with contain logic directly
  if (viewMode === 'original' || isComparingOriginal) {
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, tW, tH);

    if (viewMode === 'side-by-side') {
      const halfW = tW / 2;
      const scale = Math.min(halfW / vidW, tH / vidH) * zoom;
      const fitW = vidW * scale;
      const fitH = vidH * scale;
      const padX = (halfW - fitW) / 2;
      const padY = (tH - fitH) / 2;
      ctx.drawImage(offscreenCanvas, 0, 0, renderW, renderH, padX, padY, fitW, fitH);
      ctx.drawImage(offscreenCanvas, 0, 0, renderW, renderH, halfW + padX, padY, fitW, fitH);
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(halfW, 0);
      ctx.lineTo(halfW, tH);
      ctx.stroke();
    } else {
      const scale = Math.min(tW / vidW, tH / vidH) * zoom;
      const fitW = vidW * scale;
      const fitH = vidH * scale;
      const offX = (tW - fitW) / 2;
      const offY = (tH - fitH) / 2;
      ctx.drawImage(offscreenCanvas, 0, 0, renderW, renderH, offX, offY, fitW, fitH);
    }
    return;
  }

  // Get image data for enhancement
  const origImgData = offCtx.getImageData(0, 0, renderW, renderH);
  const enhancedImgData = offCtx.createImageData(renderW, renderH);

  applyEnhancementToImageData(origImgData, enhancedImgData, sliders, renderW, renderH);

  // Create an enhanced canvas helper
  const enhancedCanvas = document.createElement('canvas');
  enhancedCanvas.width = renderW;
  enhancedCanvas.height = renderH;
  const enhCtx = enhancedCanvas.getContext('2d');
  if (!enhCtx) return;
  enhCtx.putImageData(enhancedImgData, 0, 0);

  // Solid black background for contain bars (letterbox/pillarbox)
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, tW, tH);

  if (viewMode === 'side-by-side') {
    // Mode 2: Side-by-Side (original ratio preserved in both panes!)
    const halfW = tW / 2;
    const scale = Math.min(halfW / vidW, tH / vidH) * zoom;
    const fitW = vidW * scale;
    const fitH = vidH * scale;
    const padX = (halfW - fitW) / 2;
    const padY = (tH - fitH) / 2;

    // Left Pane: Original
    ctx.drawImage(offscreenCanvas, 0, 0, renderW, renderH, padX, padY, fitW, fitH);

    // Right Pane: Enhanced
    ctx.drawImage(enhancedCanvas, 0, 0, renderW, renderH, halfW + padX, padY, fitW, fitH);

    // Separator line
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(halfW, 0);
    ctx.lineTo(halfW, tH);
    ctx.stroke();
  } else {
    // Mode 0: Enhanced | Mode 1: Split
    const scale = Math.min(tW / vidW, tH / vidH) * zoom;
    const fitW = vidW * scale;
    const fitH = vidH * scale;
    const offX = (tW - fitW) / 2;
    const offY = (tH - fitH) / 2;

    if (viewMode === 'fullscreen') {
      ctx.drawImage(enhancedCanvas, 0, 0, renderW, renderH, offX, offY, fitW, fitH);
    } else if (viewMode === 'split') {
      const splitX = Math.round(tW * Math.max(0.05, Math.min(0.95, splitPosition)));

      // Left half: Original
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, splitX, tH);
      ctx.clip();
      ctx.drawImage(offscreenCanvas, 0, 0, renderW, renderH, offX, offY, fitW, fitH);
      ctx.restore();

      // Right half: Enhanced
      ctx.save();
      ctx.beginPath();
      ctx.rect(splitX, 0, tW - splitX, tH);
      ctx.clip();
      ctx.drawImage(enhancedCanvas, 0, 0, renderW, renderH, offX, offY, fitW, fitH);
      ctx.restore();

      // Draggable center divider line
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(splitX, 0);
      ctx.lineTo(splitX, tH);
      ctx.stroke();

      // Divider handle
      ctx.fillStyle = '#ec4899';
      ctx.beginPath();
      ctx.arc(splitX, tH / 2, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Handle arrows
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('◀▶', splitX, tH / 2);
    }
  }
}

