/**
 * Types for Reel Upscaler
 */

export interface VideoMetadata {
  file: File;
  name: string;
  sizeBytes: number;
  width: number;
  height: number;
  duration: number; // in seconds
  blobUrl: string;
  fps?: number;
}

export interface OutputMetadata {
  blobUrl: string;
  blob: Blob;
  fileName: string;
  sizeBytes: number;
  width: number;
  height: number;
  duration: number;
  totalFrames?: number;
  droppedFramesVerified?: boolean;
}

export type EngineType = 'idle' | 'multithread' | 'singlethread';

export interface PermissionState {
  isGranted: boolean;
  fileAccess: boolean;
  persistentStorage: boolean;
  downloadCapability: boolean;
  apkPermissionNotice: boolean;
}

export type QualityOption = 'best' | 'fast';
export type OutputSizeOption = '1080p' | '1440p';

export interface AdvancedSettings {
  quality: QualityOption;
  outputSize: OutputSizeOption;
}

export interface EnhancementSliders {
  neuralSharpness: number;    // 0 - 100, default 80
  denoise: number;            // 0 - 100, default 30
  detailRecovery: number;     // 0 - 100, default 65
  dynamicContrast: number;    // 0 - 100, default 28
  vibrance: number;           // 0 - 100, default 16
  antiBanding: number;        // 0 - 100, default 8
  faceProtection: boolean;    // default true
}

export type ViewMode = 'fullscreen' | 'split' | 'side-by-side' | 'original';

export interface VideoAnalysisMetrics {
  avgLuminance: number;
  laplacianVariance: number;
  noiseEstimate: number;
  avgSaturation: number;
  compressionEstimate: number;
  faceDetected: boolean;
  summaryText: string;
}

export type ProcessingStep = 
  | 'idle'
  | 'analyzing'
  | 'loading_engine'
  | 'preparing'
  | 'processing'
  | 'finishing'
  | 'completed'
  | 'error';

export interface EnhancingProgressData {
  phase: 'engine' | 'enhancing';
  enginePercent: number;
  enhancePercent: number;
  processedSeconds: number;
  totalSeconds: number;
  elapsedSeconds: number;
  isStalledWarning: boolean;
  framesProcessed?: number;
}
