/**
 * Reel Upscaler - 100% Free Browser-based Instagram Reel Enhancer
 * No server, no upload, no login, no watermark.
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Upload, 
  KeyRound, 
  AlertCircle, 
  Wand2, 
  Gift, 
  ShieldCheck,
  Smartphone,
  CheckCircle2,
  X,
  Camera,
  Download
} from 'lucide-react';
import { 
  VideoMetadata, 
  OutputMetadata, 
  PermissionState, 
  ProcessingStep, 
  AdvancedSettings,
  EnhancingProgressData,
  EnhancementSliders,
  VideoAnalysisMetrics
} from './types';
import { PermissionsModal } from './components/PermissionsModal';
import { LiveCanvasPreview } from './components/LiveCanvasPreview';
import { RecordClipModal } from './components/RecordClipModal';
import { SmoothLockCard } from './components/SmoothLockCard';
import { EnhancementSlidersCard } from './components/EnhancementSlidersCard';
import { ProcessingCard } from './components/ProcessingCard';
import { ResultCard } from './components/ResultCard';
import { LongVideoWarningModal } from './components/LongVideoWarningModal';
import { AdvancedSettingsCard } from './components/AdvancedSettingsCard';
import { 
  autoEnhanceVideo, 
  getOrInitFFmpeg, 
  cancelCurrentEnhancement 
} from './utils/ffmpegManager';
import { generateSampleReel } from './utils/sampleReelGenerator';
import { analyzeVideo, DEFAULT_SLIDERS } from './utils/videoAnalyzer';

export default function App() {
  // Permission State
  const [permissions, setPermissions] = useState<PermissionState>(() => {
    const saved = localStorage.getItem('reel_upscaler_perms_v1');
    return {
      isGranted: saved === 'granted',
      fileAccess: saved === 'granted',
      persistentStorage: saved === 'granted',
      downloadCapability: saved === 'granted',
      apkPermissionNotice: false,
    };
  });
  const [showPermissionsModal, setShowPermissionsModal] = useState<boolean>(() => {
    const saved = localStorage.getItem('reel_upscaler_perms_v1');
    return saved !== 'granted';
  });

  // Video State
  const [inputVideo, setInputVideo] = useState<VideoMetadata | null>(null);
  const [outputVideo, setOutputVideo] = useState<OutputMetadata | null>(null);
  const [isDemoMode, setIsDemoMode] = useState<boolean>(false);

  // Enhancement Sliders State (Defaults)
  const [sliders, setSliders] = useState<EnhancementSliders>(DEFAULT_SLIDERS);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisMetrics, setAnalysisMetrics] = useState<VideoAnalysisMetrics | null>(null);
  const [autoNotice, setAutoNotice] = useState<string | null>(null);

  // 60 FPS Smooth Lock State (Default ON)
  const [fpsLocked, setFpsLocked] = useState<boolean>(true);

  // Advanced Export Settings State (Default: Best crf 14, 1080p)
  const [advancedSettings, setAdvancedSettings] = useState<AdvancedSettings>({
    quality: 'best',
    outputSize: '1080p',
  });

  // Playback State
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);

  // Processing State
  const [processingStep, setProcessingStep] = useState<ProcessingStep>('idle');
  const [progressData, setProgressData] = useState<EnhancingProgressData>({
    phase: 'engine',
    enginePercent: 0,
    enhancePercent: 0,
    processedSeconds: 0,
    totalSeconds: 0,
    elapsedSeconds: 0,
    isStalledWarning: false,
  });
  const [processingError, setProcessingError] = useState<string | null>(null);
  const [showLongVideoModal, setShowLongVideoModal] = useState<boolean>(false);
  const [cancelNotification, setCancelNotification] = useState<string | null>(null);
  const [isRecordModalOpen, setIsRecordModalOpen] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const hiddenVideoRef = useRef<HTMLVideoElement | null>(null);

  // Pre-warm engine in background
  useEffect(() => {
    if (permissions.isGranted) {
      getOrInitFFmpeg().catch((err) => {
        console.warn('Background engine pre-load notice:', err);
      });
    }
  }, [permissions.isGranted]);

  // Demo State: Load demo reel on initial start if no video chosen
  useEffect(() => {
    let isMounted = true;
    const loadInitialDemo = async () => {
      try {
        const demoFile = await generateSampleReel();
        if (!isMounted) return;
        await processSelectedFile(demoFile, true);
      } catch (err) {
        console.warn('Initial demo reel notice:', err);
      }
    };

    if (!inputVideo) {
      loadInitialDemo();
    }

    return () => {
      isMounted = false;
    };
  }, []);

  const cleanupUrls = () => {
    if (inputVideo?.blobUrl) {
      URL.revokeObjectURL(inputVideo.blobUrl);
    }
    if (outputVideo?.blobUrl) {
      URL.revokeObjectURL(outputVideo.blobUrl);
    }
  };

  const handlePermissionsGranted = (pickedFile?: File) => {
    const newState: PermissionState = {
      isGranted: true,
      fileAccess: true,
      persistentStorage: true,
      downloadCapability: true,
      apkPermissionNotice: false,
    };
    setPermissions(newState);
    setShowPermissionsModal(false);

    if (pickedFile) {
      processSelectedFile(pickedFile, false);
    }
  };

  // Run automatic video analysis and set sliders
  const runAutoAnalysis = async (meta: VideoMetadata, showBanner = false) => {
    setIsAnalyzing(true);
    try {
      const result = await analyzeVideo(
        meta.file,
        meta.width,
        meta.height,
        meta.duration,
        meta.sizeBytes
      );
      setSliders(result.sliders);
      setAnalysisMetrics(result.metrics);
      if (showBanner) {
        setAutoNotice('Auto settings lag gayi hain — chaaho to sliders se badal sakte ho, phir EXPORT dabao.');
      }
    } catch (err) {
      console.warn('Video analysis notice, using default sliders:', err);
      setSliders(DEFAULT_SLIDERS);
      setAnalysisMetrics({
        avgLuminance: 120,
        laplacianVariance: 250,
        noiseEstimate: 2.1,
        avgSaturation: 0.32,
        compressionEstimate: 0.04,
        faceDetected: true,
        summaryText: 'Analysis nahi ho payi, default settings lagi hain.',
      });
      if (showBanner) {
        setAutoNotice('Auto settings lag gayi hain — chaaho to sliders se badal sakte ho, phir EXPORT dabao.');
      }
    } finally {
      setIsAnalyzing(false);
    }
  };

  const processSelectedFile = async (file: File, isDemo = false) => {
    setProcessingError(null);
    setOutputVideo(null);
    setProcessingStep('idle');
    setCancelNotification(null);
    setAutoNotice(null);
    setIsDemoMode(isDemo);

    if (inputVideo?.blobUrl && !isDemoMode) {
      URL.revokeObjectURL(inputVideo.blobUrl);
    }

    try {
      const blobUrl = URL.createObjectURL(file);
      const videoEl = document.createElement('video');
      videoEl.preload = 'metadata';
      videoEl.src = blobUrl;

      await new Promise<void>((resolve, reject) => {
        videoEl.onloadedmetadata = () => resolve();
        videoEl.onerror = () =>
          reject(new Error('Video format read nahi ho paaya. Kripya MP4, MOV, WebM ya MKV chunein.'));
      });

      const width = videoEl.videoWidth || 720;
      const height = videoEl.videoHeight || 1280;
      const duration = videoEl.duration || 0;

      const newMeta: VideoMetadata = {
        file,
        name: file.name,
        sizeBytes: file.size,
        width,
        height,
        duration,
        blobUrl,
        fps: 30,
      };

      setInputVideo(newMeta);
      setCurrentTime(0);
      setIsPlaying(false);

      // AUTOMATIC SLIDER VALUES: analyze video immediately
      runAutoAnalysis(newMeta, false);
    } catch (err: any) {
      setProcessingError(err.message || 'Video read karne me truti aayi.');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processSelectedFile(e.target.files[0], false);
    }
  };

  const handlePlayPause = () => {
    const video = hiddenVideoRef.current;
    if (!video) return;

    if (video.paused) {
      video.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  const handleSeek = (time: number) => {
    const video = hiddenVideoRef.current;
    if (video) {
      video.currentTime = time;
      setCurrentTime(time);
    }
  };

  const handleImportClick = () => {
    if (!permissions.isGranted || !permissions.fileAccess) {
      setShowPermissionsModal(true);
    } else {
      fileInputRef.current?.click();
    }
  };

  const handleRecordClick = () => {
    if (!permissions.isGranted || !permissions.fileAccess) {
      setShowPermissionsModal(true);
    } else {
      setIsRecordModalOpen(true);
    }
  };

  // Button 1: "AUTO" (Only sets sliders, NEVER starts export)
  const handleAutoButtonClick = () => {
    if (!inputVideo) return;
    runAutoAnalysis(inputVideo, true);
  };

  // Button 2: "EXPORT" (Exports with current slider values)
  const handleExportButtonClick = () => {
    if (!permissions.isGranted || !permissions.fileAccess) {
      setShowPermissionsModal(true);
      return;
    }

    if (!inputVideo) return;

    // Check if video is longer than 90 seconds
    if (inputVideo.duration > 90) {
      setShowLongVideoModal(true);
      return;
    }

    startEnhancement();
  };

  const startEnhancement = async () => {
    setShowLongVideoModal(false);
    setAutoNotice(null);
    if (!inputVideo) return;

    // Pause playback before encoding
    if (hiddenVideoRef.current) {
      hiddenVideoRef.current.pause();
      setIsPlaying(false);
    }

    setProcessingStep('processing');
    setProgressData({
      phase: 'engine',
      enginePercent: 10,
      enhancePercent: 0,
      processedSeconds: 0,
      totalSeconds: inputVideo.duration,
      elapsedSeconds: 0,
      isStalledWarning: false,
    });
    setProcessingError(null);
    setCancelNotification(null);

    try {
      const result = await autoEnhanceVideo({
        file: inputVideo.file,
        originalWidth: inputVideo.width,
        originalHeight: inputVideo.height,
        totalDuration: inputVideo.duration,
        settings: advancedSettings,
        sliders,
        fpsLock: fpsLocked,
        onProgressData: (data) => setProgressData(data),
      });

      // COMPLETION GUARANTEE: Read and strictly verify output video
      const outVideoEl = document.createElement('video');
      outVideoEl.preload = 'metadata';
      outVideoEl.src = result.blobUrl;

      await new Promise<void>((resolve, reject) => {
        outVideoEl.onloadedmetadata = () => resolve();
        outVideoEl.onerror = () => reject(new Error('Corrupt video output generated'));
      });

      const outDuration = outVideoEl.duration || 0;
      const outWidth = outVideoEl.videoWidth || result.targetWidth;
      const outHeight = outVideoEl.videoHeight || result.targetHeight;

      // Verify file size > 0 and duration within 0.1s
      const isValidSize = result.blob.size > 1024;
      const isDurationValid = Math.abs(outDuration - inputVideo.duration) <= 0.15;

      if (!isValidSize || !isDurationValid) {
        throw new Error(
          'Export verification fail ho gaya (adhoori file detect hui) — Dobara koshish karein.'
        );
      }

      setOutputVideo({
        blobUrl: result.blobUrl,
        blob: result.blob,
        fileName: result.outputName,
        sizeBytes: result.blob.size,
        width: outWidth,
        height: outHeight,
        duration: outDuration,
        totalFrames: result.totalFrames,
        droppedFramesVerified: true,
      });

      setProcessingStep('completed');
    } catch (err: any) {
      console.error(err);
      if (err.message && err.message.includes('cancel')) {
        setProcessingStep('idle');
        return;
      }
      setProcessingStep('error');
      setProcessingError(
        err.message || 'Phone ki memory kam pad gayi — chhota clip ya 1080p par try karo'
      );
    }
  };

  const handleCancelExport = () => {
    cancelCurrentEnhancement();
    if (outputVideo?.blobUrl) {
      URL.revokeObjectURL(outputVideo.blobUrl);
      setOutputVideo(null);
    }
    setProcessingStep('idle');
    setProgressData({
      phase: 'engine',
      enginePercent: 0,
      enhancePercent: 0,
      processedSeconds: 0,
      totalSeconds: inputVideo ? inputVideo.duration : 0,
      elapsedSeconds: 0,
      isStalledWarning: false,
    });
    setProcessingError(null);
    setCancelNotification('Export cancel kar diya — koi adhoori file save nahi hui');
  };

  const handleReset = () => {
    cleanupUrls();
    setInputVideo(null);
    setOutputVideo(null);
    setIsDemoMode(false);
    setAutoNotice(null);
    setProcessingStep('idle');
    setProgressData({
      phase: 'engine',
      enginePercent: 0,
      enhancePercent: 0,
      processedSeconds: 0,
      totalSeconds: 0,
      elapsedSeconds: 0,
      isStalledWarning: false,
    });
    setProcessingError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start p-3 sm:p-5 selection:bg-pink-500 selection:text-white">
      {/* First-Run & On-Demand Permissions Modal */}
      <PermissionsModal
        isOpen={showPermissionsModal}
        onClose={() => setShowPermissionsModal(false)}
        onPermissionsGranted={handlePermissionsGranted}
        currentPermissions={permissions}
      />

      {/* Long Video (>90s) Confirmation Modal */}
      {inputVideo && (
        <LongVideoWarningModal
          isOpen={showLongVideoModal}
          durationSeconds={inputVideo.duration}
          onContinue={startEnhancement}
          onCancel={() => setShowLongVideoModal(false)}
        />
      )}

      {/* Camera Record Clip Modal (up to 60s) */}
      <RecordClipModal
        isOpen={isRecordModalOpen}
        onClose={() => setIsRecordModalOpen(false)}
        onClipRecorded={(file) => processSelectedFile(file, false)}
      />

      {/* Hidden Master Video Element for Driving Canvas Preview */}
      {inputVideo && (
        <video
          ref={hiddenVideoRef}
          src={inputVideo.blobUrl}
          playsInline
          muted
          loop
          onTimeUpdate={() => {
            if (hiddenVideoRef.current) {
              setCurrentTime(hiddenVideoRef.current.currentTime);
            }
          }}
          onEnded={() => setIsPlaying(false)}
          className="hidden"
        />
      )}

      {/* Main Container - Mobile-first width */}
      <div className="w-full max-w-md mx-auto flex flex-col gap-4 pb-12 pt-2">
        {/* Header Bar */}
        <header className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-lg backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-pink-500 via-rose-500 to-amber-500 p-0.5 shadow-md shadow-pink-500/25 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-pink-400" />
              </div>
            </div>
            <div>
              <h1 className="text-base font-extrabold tracking-tight bg-gradient-to-r from-pink-400 via-rose-300 to-amber-200 bg-clip-text text-transparent">
                Reel Upscaler
              </h1>
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                <span className="text-emerald-400 font-semibold flex items-center gap-0.5">
                  <Gift className="w-3 h-3 inline" /> 100% Free
                </span>
                <span>• No Watermark</span>
              </div>
            </div>
          </div>

          {/* Permissions Re-open Button */}
          <button
            onClick={() => setShowPermissionsModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700/80 text-xs font-medium text-slate-300 hover:text-white transition-all active:scale-95 cursor-pointer"
            title="Check or allow permissions"
          >
            <KeyRound className="w-3.5 h-3.5 text-pink-400" />
            <span>Permissions</span>
          </button>
        </header>

        {/* Tagline Card */}
        <div className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-pink-500/10 via-purple-500/10 to-blue-500/10 border border-pink-500/20 text-center">
          <p className="text-xs font-medium text-pink-200/90">
            No quality loss • Same FPS • Same duration • Original audio
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">
            100% phone browser ke andar chalta hai • Koi video upload nahi hoti
          </p>
        </div>

        {/* Hidden File Picker Input */}
        <input
          ref={fileInputRef}
          type="file"
          accept="video/mp4,video/quicktime,video/webm,video/x-matroska,.mp4,.mov,.webm,.mkv"
          onChange={handleFileChange}
          className="hidden"
        />

        {/* MAIN BODY: PREVIEW, CONTROLS, EXPORT */}

        {/* RESULT SECTION (shown when enhancement is complete) */}
        {processingStep === 'completed' && outputVideo && inputVideo ? (
          <ResultCard
            inputMeta={inputVideo}
            outputMeta={outputVideo}
            onReset={handleReset}
          />
        ) : processingStep === 'processing' || processingStep === 'loading_engine' || processingStep === 'error' ? (
          /* PROCESSING / PROGRESS CARD (Phase 1 & Phase 2 with Red Cancel button) */
          <ProcessingCard
            progressData={progressData}
            error={processingError}
            onRetry={startEnhancement}
            onCancel={handleCancelExport}
          />
        ) : (
          /* ACTIVE EDITOR / ENHANCER VIEW */
          <div className="space-y-4">
            {/* Top Media Action Bar: Import (Prominent) + Record Clip */}
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={handleImportClick}
                className="py-3 px-4 rounded-2xl bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-pink-600/25 active:scale-95 transition-all cursor-pointer"
                title="Choose a video from your device"
              >
                <Upload className="w-4 h-4 stroke-[2.5]" />
                <span>Import</span>
              </button>

              <button
                type="button"
                onClick={handleRecordClick}
                className="py-3 px-4 rounded-2xl bg-slate-800/90 hover:bg-slate-800 border border-slate-700/80 text-pink-200 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all cursor-pointer"
                title="Record a clip with your camera (up to 60s)"
              >
                <Camera className="w-4 h-4 text-pink-400" />
                <span>Record Clip</span>
              </button>
            </div>

            {/* 1. LIVE CANVAS PREVIEW (Portrait 9:16 with Overlay Transport, 4 View Modes, GPU Acceleration & FPS Meter) */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 shadow-xl backdrop-blur-md space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    Live Preview
                  </span>
                </div>
                {isDemoMode && inputVideo && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold">
                    Demo Reel Active
                  </span>
                )}
              </div>

              <LiveCanvasPreview
                videoRef={hiddenVideoRef}
                sliders={sliders}
                isPlaying={isPlaying}
                currentTime={currentTime}
                duration={inputVideo ? inputVideo.duration : 0}
                fps={inputVideo?.fps || 30}
                inputVideo={inputVideo}
                onPlayPause={handlePlayPause}
                onSeek={handleSeek}
                onImportClick={handleImportClick}
                onRecordClick={handleRecordClick}
              />
            </div>

            {/* 2. 60 FPS SMOOTH LOCK CARD */}
            <SmoothLockCard
              isLocked={fpsLocked}
              onToggle={setFpsLocked}
            />

            {/* 4. ENHANCEMENT SLIDERS (Driving Preview & Export) */}
            {inputVideo && (
              <EnhancementSlidersCard
                sliders={sliders}
                onChange={setSliders}
                onAutoAnalyze={handleAutoButtonClick}
                isAnalyzing={isAnalyzing}
                analysisMetrics={analysisMetrics}
              />
            )}

            {/* 5. TWO SEPARATE BUTTONS: AUTO AND EXPORT */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl backdrop-blur-md space-y-3.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center font-bold text-xs">
                    ⚡
                  </span>
                  <h2 className="text-sm font-bold text-slate-100 uppercase tracking-wider">
                    Enhance & Export
                  </h2>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 font-medium">
                  {advancedSettings.outputSize} • {advancedSettings.quality === 'best' ? 'CRF 14' : 'CRF 20'}
                </span>
              </div>

              {/* Pre-export App Switching Warning */}
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 text-[11px] text-slate-300">
                <Smartphone className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  Export ke dauraan app ko khula rakho — dusre app me jaane par browser kaam rok deta hai.
                </span>
              </div>

              {/* Cancel Notification Banner if cancelled */}
              {cancelNotification && (
                <div className="flex items-center justify-between p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs shadow-md animate-fade-in">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="font-medium">{cancelNotification}</span>
                  </div>
                  <button
                    onClick={() => setCancelNotification(null)}
                    className="p-1 hover:text-white text-slate-400 rounded-md cursor-pointer"
                    title="Dismiss"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Auto Settings Applied Banner */}
              {autoNotice && (
                <div className="p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-200 text-xs flex items-center justify-between shadow-md animate-fade-in">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="font-medium">{autoNotice}</span>
                  </div>
                  <button
                    onClick={() => setAutoNotice(null)}
                    className="p-1 hover:text-white text-slate-400 rounded-md cursor-pointer"
                    title="Dismiss"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* SPLIT INTO TWO DISTINCT BUTTONS: AUTO AND EXPORT */}
              {(() => {
                const isPermissionMissing = !permissions.isGranted || !permissions.fileAccess;
                const isVideoMissing = !inputVideo;
                const isDisabled = isPermissionMissing || isVideoMissing;

                let disabledReason = '';
                if (isPermissionMissing) {
                  disabledReason = 'Pehle permissions allow karo';
                } else if (isVideoMissing) {
                  disabledReason = 'Pehle video select karein';
                }

                return (
                  <div className="space-y-2.5">
                    <div className="grid grid-cols-2 gap-2.5">
                      {/* BUTTON 1: "AUTO" (Only sets sliders, NEVER exports) */}
                      <button
                        type="button"
                        onClick={handleAutoButtonClick}
                        disabled={isAnalyzing || isVideoMissing}
                        className="py-4 px-3 rounded-2xl font-bold text-sm text-slate-200 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700/80 shadow-md flex items-center justify-center gap-2 active:scale-[0.98] transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                        title="Analyze video and set sliders automatically"
                      >
                        <Wand2 className={`w-4 h-4 text-pink-400 ${isAnalyzing ? 'animate-spin' : ''}`} />
                        <span>AUTO</span>
                      </button>

                      {/* BUTTON 2: "EXPORT" (Exports with current sliders) */}
                      <button
                        type="button"
                        onClick={handleExportButtonClick}
                        disabled={isDisabled}
                        className={`py-4 px-3 rounded-2xl font-bold text-sm text-white shadow-xl flex items-center justify-center gap-2 active:scale-[0.98] transition-all ${
                          isDisabled
                            ? 'bg-slate-800 text-slate-500 border border-slate-700/60 cursor-not-allowed shadow-none'
                            : 'bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 hover:from-pink-500 hover:via-rose-500 hover:to-purple-500 shadow-pink-600/30 cursor-pointer'
                        }`}
                        title="Export video with current settings"
                      >
                        <Download className="w-4 h-4 stroke-[2.5]" />
                        <span>EXPORT</span>
                      </button>
                    </div>

                    {isDisabled && (
                      <div className="flex items-center justify-center gap-1.5 text-xs text-amber-400/90 py-1">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{disabledReason}</span>
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Optional Collapsed Advanced Section (closed by default) */}
              <AdvancedSettingsCard
                settings={advancedSettings}
                onChange={setAdvancedSettings}
              />
            </div>
          </div>
        )}

        {/* Small Footer Note */}
        <footer className="mt-2 text-center space-y-2 px-2">
          <p className="text-[11px] text-slate-400 leading-relaxed">
            "Instagram upload par halka compression hota hi hai, isliye export maximum quality par hota hai taaki final video crisp rahe."
          </p>

          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-800 text-[11px] text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>100% Free of Cost • Safe in-browser • No data leaves your device</span>
          </div>
        </footer>
      </div>
    </div>
  );
}
